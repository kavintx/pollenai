import { AudioLines, Camera, Check, House, Mic, Video, X } from "lucide-react"
import { Eyebrow, SectionTitle } from "./logo"
import { PayRates } from "./pay-rates"

/* ------------------------------------------------------------ marquee */

const MARQUEE = ["Video", "Photos", "Voice clips", "Ambient audio", "Everyday scenes", "Get paid"]

export function Marquee() {
  const items = [...MARQUEE, ...MARQUEE]
  return (
    <div aria-hidden className="overflow-hidden border-b border-[rgba(36,53,10,.12)] py-7">
      <div className="extra-wide flex w-max animate-marquee gap-9 font-display text-[clamp(24px,3.2vw,40px)] font-black tracking-[-0.02em] whitespace-nowrap text-ink-2 uppercase">
        {items.map((t, i) => (
          <span key={i} className="flex items-center gap-9">
            <span>{t}</span>
            <span className="text-[#3e8a18]">⬢</span>
          </span>
        ))}
      </div>
    </div>
  )
}

/* ------------------------------------------------------- how it works */

const STEPS = [
  { n: "01", title: "Get a shot list", body: "The app tells you what AI companies need right now — like a rainy street at night or 30 seconds of a busy café. Pick the ones you can get." },
  { n: "02", title: "Shoot it for real", body: "Snap or record it on your phone. Real photos and real sound only — nothing AI-generated, no lazy shots of a blank wall." },
  { n: "03", title: "We check & match it", body: "Every upload gets a quick quality check, then goes into datasets for the AI companies that asked for exactly that." },
  { n: "04", title: "You get paid", body: "When a dataset with your stuff in it gets licensed, you get your cut. Every payout shows exactly where it came from." },
]

export function HowItWorks() {
  return (
    <section className="px-5 py-[clamp(72px,9vw,128px)]">
      <div className="mx-auto flex max-w-[1240px] flex-col gap-[clamp(36px,5vw,64px)]">
        <div className="flex max-w-[760px] flex-col gap-3.5">
          <Eyebrow>How it works</Eyebrow>
          <SectionTitle>Four steps. Zero guesswork.</SectionTitle>
        </div>
        <ol className="m-0 grid list-none grid-cols-[repeat(auto-fit,minmax(min(260px,100%),1fr))] gap-4 p-0">
          {STEPS.map((s, i) => {
            const last = i === STEPS.length - 1
            return (
              <li
                key={s.n}
                className={`flex min-h-[290px] flex-col gap-[18px] rounded-[30px] p-7 transition duration-300 hover:-translate-y-1.5 hover:shadow-[0_18px_40px_rgba(61,90,14,.12)] ${
                  last ? "bg-forest" : "border border-[rgba(36,53,10,.08)] bg-white"
                }`}
              >
                <span className={`extra-wide grid size-16 place-items-center rounded-[20px] font-display text-[26px] font-black text-ink-2 ${last ? "bg-lime" : "border border-[#dcebae] bg-white"}`}>
                  {s.n}
                </span>
                <h3 className={`wide mt-auto mb-0 font-display text-[32px] font-extrabold tracking-[-0.03em] ${last ? "text-lime" : "text-ink"}`}>{s.title}</h3>
                <p className={`m-0 text-base leading-relaxed ${last ? "font-medium text-[#e4f8d6]" : "text-moss"}`}>{s.body}</p>
              </li>
            )
          })}
        </ol>
      </div>
    </section>
  )
}

/* ---------------------------------------------------- what you can sell */

const SELLABLE = [
  { icon: Video, title: "Video", body: "Short clips of real life — your hands at work, a walk through a room, cooking POV. Pays the most.", tint: "bg-lime" },
  { icon: Camera, title: "Photos", body: "Pets, food, skies, streets, your fit check — the stuff already sitting in your camera roll.", tint: "bg-[#eaf5c6]" },
  { icon: Mic, title: "Voice clips", body: "Read short prompts in your own voice. Never sold unless you explicitly opt in.", tint: "bg-lime" },
  { icon: AudioLines, title: "Ambient audio", body: "Rain, traffic, cafés, crowds, the hum of your room — the background noise of your day.", tint: "bg-[#eaf5c6]" },
  { icon: House, title: "Everyday scenes", body: "Kitchens, desks, commutes, store aisles. Real life, not stock-photo life.", tint: "bg-lime" },
]

export function WhatYouCanSell() {
  return (
    <section className="px-5 pb-[clamp(72px,9vw,128px)]">
      <div className="mx-auto flex max-w-[1240px] flex-col gap-[clamp(36px,5vw,64px)]">
        <div className="flex max-w-[760px] flex-col gap-3.5">
          <Eyebrow>What you can sell</Eyebrow>
          <SectionTitle>Stuff you already have.</SectionTitle>
        </div>
        <div className="grid grid-cols-[repeat(auto-fit,minmax(min(220px,100%),1fr))] gap-4">
          {SELLABLE.map(({ icon: Icon, title, body, tint }) => (
            <div
              key={title}
              className="flex min-h-[270px] flex-col gap-4 rounded-[30px] border border-[rgba(36,53,10,.08)] bg-white p-[26px] transition duration-300 hover:-translate-y-1.5 hover:shadow-[0_18px_40px_rgba(61,90,14,.12)]"
            >
              <div className={`grid size-[58px] place-items-center rounded-[18px] text-ink-2 ${tint}`}>
                <Icon className="size-[26px]" strokeWidth={2.2} aria-hidden />
              </div>
              <h3 className="wide mt-auto mb-0 font-display text-[28px] font-extrabold tracking-[-0.03em] text-ink">{title}</h3>
              <p className="m-0 text-[15px] leading-relaxed text-moss">{body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* -------------------------------------------------------- real shots */

const YES = ["Photos and sound you captured yourself", "Shots from your shot list", "In focus, well lit, clearly the subject", "Real places, real moments, real noise"]
const NO = ["Anything AI-generated or AI-edited", "Screenshots, reposts or other people's stuff", "Filler — blank walls, ceilings, the floor", "Blurry, dark or near-duplicate shots"]

export function RealShotsOnly() {
  return (
    <section className="px-5 pb-[clamp(72px,9vw,128px)]">
      <div className="mx-auto flex max-w-[1240px] flex-col gap-[clamp(32px,5vw,56px)]">
        <div className="flex max-w-[760px] flex-col gap-3.5">
          <Eyebrow>The rules</Eyebrow>
          <SectionTitle>Real shots only.</SectionTitle>
          <p className="m-0 max-w-[560px] text-[17px] leading-relaxed text-moss">
            AI companies come to Pollen for the real world, so that&apos;s all we sell. Every upload gets checked before it
            goes anywhere.
          </p>
        </div>
        <div className="grid grid-cols-[repeat(auto-fit,minmax(min(380px,100%),1fr))] gap-4">
          <div className="flex flex-col gap-4 rounded-[30px] bg-white p-[clamp(22px,3vw,32px)]">
            <h3 className="wide m-0 font-display text-[28px] font-extrabold tracking-[-0.03em] text-ink">We pay for</h3>
            <ul className="m-0 flex list-none flex-col gap-3 p-0">
              {YES.map((t) => (
                <li key={t} className="flex items-center gap-3 text-base font-semibold text-ink-2">
                  <span className="grid size-8 shrink-0 place-items-center rounded-full bg-lime">
                    <Check className="size-4" strokeWidth={3} aria-hidden />
                  </span>
                  {t}
                </li>
              ))}
            </ul>
          </div>
          <div className="flex flex-col gap-4 rounded-[30px] bg-forest p-[clamp(22px,3vw,32px)]">
            <h3 className="wide m-0 font-display text-[28px] font-extrabold tracking-[-0.03em] text-lime">We don&apos;t</h3>
            <ul className="m-0 flex list-none flex-col gap-3 p-0">
              {NO.map((t) => (
                <li key={t} className="flex items-center gap-3 text-base font-semibold text-[#e4f8d6]">
                  <span className="grid size-8 shrink-0 place-items-center rounded-full bg-white/10 text-lime">
                    <X className="size-4" strokeWidth={3} aria-hidden />
                  </span>
                  {t}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}

/* -------------------------------------------------------------- trust */

const PROMISES = [
  { title: "You choose what gets sold", body: "Uploading isn't selling. You mark exactly which files are up for license." },
  { title: "Clear consent on every upload", body: "Plain-English terms, every time. No buried checkboxes." },
  { title: "No faces or voices without opt-in", body: "Anything that could identify you stays off the table unless you explicitly say yes." },
  { title: "Delete anytime", body: "Pull a file or your whole account whenever you want." },
  { title: "Transparent payouts", body: "See which files sold, what the license paid, and what landed in your account." },
]

function MockToggle({ label, on }: { label: string; on?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-4 rounded-[18px] bg-mint p-3.5">
      <span className="text-[15px] font-semibold">{label}</span>
      <span className={`flex h-7 w-12 rounded-full p-[3px] ${on ? "justify-end bg-lime-2" : "bg-[#dce3cc]"}`}>
        <span className="size-[22px] rounded-full bg-white shadow-[0_1px_3px_rgba(45,69,0,.3)]" />
      </span>
    </div>
  )
}

export function Trust() {
  return (
    <section className="px-3">
      <div className="rounded-[36px] bg-white/40 py-[clamp(56px,8vw,112px)]">
        <div className="mx-auto grid max-w-[1240px] grid-cols-[repeat(auto-fit,minmax(min(460px,100%),1fr))] items-start gap-[clamp(40px,6vw,88px)] px-[clamp(16px,3vw,28px)]">
          <div className="flex flex-col gap-5">
            <Eyebrow>You&apos;re in control</Eyebrow>
            <SectionTitle>
              Your stuff.
              <br />
              Your call.
            </SectionTitle>
            <p className="m-0 max-w-[460px] text-[17px] leading-relaxed text-moss">
              Nothing gets sold without a yes from you. Every upload comes with its own consent screen, and you can change
              your mind whenever.
            </p>
            <div aria-hidden className="flex max-w-[420px] flex-col gap-1.5 rounded-[26px] bg-white p-2.5 shadow-[0_14px_34px_rgba(45,69,0,.1)]">
              <MockToggle label="Sell this photo" on />
              <MockToggle label="Includes faces — opt in" />
              <MockToggle label="Sell my voice — opt in" />
            </div>
          </div>
          <ul className="m-0 flex list-none flex-col gap-2.5 p-0">
            {PROMISES.map((p) => (
              <li key={p.title} className="flex gap-4 rounded-[22px] bg-white p-5">
                <span className="grid size-[34px] shrink-0 place-items-center rounded-full bg-lime text-ink-2">
                  <Check className="size-4" strokeWidth={3} aria-hidden />
                </span>
                <div className="flex flex-col gap-1">
                  <h3 className="m-0 text-[19px] font-extrabold text-ink">{p.title}</h3>
                  <p className="m-0 text-[15px] leading-normal text-moss">{p.body}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}

/* ----------------------------------------------------------- earnings */

export function Earnings() {
  return (
    <section className="px-5 py-[clamp(72px,9vw,128px)]">
      <div className="mx-auto flex max-w-[1240px] flex-col gap-[clamp(32px,5vw,56px)]">
        <div className="flex max-w-[760px] flex-col gap-3.5">
          <Eyebrow>What you earn</Eyebrow>
          <SectionTitle className="leading-[1.06]">
            Real pay.{" "}
            <span className="rounded-[.12em] bg-white px-[.1em] [box-decoration-break:clone] [-webkit-box-decoration-break:clone]">Per task.</span>
          </SectionTitle>
          <p className="m-0 max-w-[560px] text-[17px] leading-relaxed text-moss">
            Every task on your shot list shows what it pays before you start. Longer, harder-to-get footage pays more —
            video pays the most.
          </p>
        </div>
        <PayRates />
      </div>
    </section>
  )
}
