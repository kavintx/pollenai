# Pollen — waitlist site

Next.js 16 · TypeScript · Tailwind CSS v4 · shadcn structure · lucide-react icons.

## Run it

```bash
npm install
npm run dev        # http://localhost:3000
```

Without Supabase env vars the waitlist uses an in-memory store, so you can test signups locally. It resets every restart.

## Make the waitlist real (Supabase, ~5 min)

1. Create a project at supabase.com.
2. SQL Editor → paste `supabase/schema.sql` → Run.
3. Project Settings → API: copy the **Project URL** and the **service_role** key.
4. Copy `.env.example` to `.env.local` and fill in `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` (and `NEXT_PUBLIC_SITE_URL` once you have a domain).

The service role key is only used on the server (`app/api/waitlist/route.ts`). Never put it in a `NEXT_PUBLIC_` variable.

How the list works:
- `POST /api/waitlist { email, ref? }` returns `{ position, refCode, referrals, alreadyJoined }`. Signing up twice returns the same spot.
- Referral links look like `/?ref=CODE`. Each friend who joins moves the referrer up 5 spots (`SPOTS_PER_REFERRAL` in `lib/waitlist-store.ts`).
- `GET /api/waitlist` returns the live count shown in the hero badge.

## Deploy to Vercel

1. Push this folder to a GitHub repo.
2. vercel.com → New Project → import the repo. It detects Next.js automatically.
3. Add the same env vars under Settings → Environment Variables, then redeploy.
4. Settings → Domains to connect your domain.

## Project layout (shadcn)

```
app/
  layout.tsx            fonts (Archivo, Manrope, JetBrains Mono), metadata
  page.tsx              the landing page
  globals.css           Tailwind v4 theme: Pollen colors, fonts, animations
  api/waitlist/route.ts signup + count API
  carousel-demo/        the carousel's original demo (/carousel-demo)
components/
  ui/                   shadcn-style reusable primitives
    polaroid-line-carousel.tsx
  site/                 page sections (hero, waitlist form, FAQ, …)
lib/
  utils.ts              cn() helper used by shadcn components
  waitlist-store.ts     Supabase / in-memory storage
public/carousel/        your photos for the carousel
supabase/schema.sql
components.json         shadcn config, so `npx shadcn add button` etc. drop into components/ui
```

**Why `components/ui`?** It's where the shadcn CLI installs components (set in `components.json`) and what the `@/components/ui/...` imports point to. Keeping reusable primitives there and page sections in `components/site` means new shadcn components slot straight in without moving anything.

## Before launch, fill in

- Per-task pay estimates: `components/site/pay-rates.tsx`
- `[PARTNER NAMES]` in `components/site/faq.tsx`
- Terms draft at `app/terms/page.tsx` (`/terms`): fill `[COMPANY LEGAL NAME]`, `[COUNTY]`, the contact email, the Privacy Policy link, and get it reviewed
- A Privacy Policy page, since you're collecting emails

## Carousel photos

Drop JPGs into `public/carousel/` and list them in `components/site/on-the-line.tsx`.
