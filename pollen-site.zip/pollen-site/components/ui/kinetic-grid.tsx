"use client"

import * as React from "react"

/*
 * Kinetic Grid — a full-viewport grid that bends toward the pointer, lights up
 * the lines and dots near it, and sends a ripple out from every click / tap.
 * Sits behind the page (pointer-events: none) and listens on window, so the
 * content above it stays fully clickable.
 */

export type KineticGridProps = {
  /** Grid cell size in px (auto-shrinks a little on phones). */
  spacing?: number
  /** Colour of the lines, dots and glow. */
  color?: string
  /** Resting opacity of the lines (0–1). */
  lineOpacity?: number
  /** Radius of the pointer's influence, px. */
  radius?: number
  /** How hard the grid is pulled toward the pointer (0–1). */
  pull?: number
  className?: string
}

type Ripple = { x: number; y: number; t: number }

function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace("#", "")
  const v = parseInt(h.length === 3 ? h.split("").map((c) => c + c).join("") : h, 16)
  return [(v >> 16) & 255, (v >> 8) & 255, v & 255]
}

export default function KineticGrid({
  spacing = 64,
  color = "#2d4500",
  lineOpacity = 0.14,
  radius = 190,
  pull = 0.28,
  className,
}: KineticGridProps) {
  const ref = React.useRef<HTMLCanvasElement>(null)

  React.useEffect(() => {
    const canvas = ref.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const [r, g, b] = hexToRgb(color)
    const rgba = (a: number) => `rgba(${r},${g},${b},${a})`
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches

    let W = 0
    let H = 0
    let step = spacing
    let cols = 0
    let rows = 0
    let ox = 0
    let oy = 0
    const target = { x: -9999, y: -9999 }
    const ptr = { x: -9999, y: -9999, on: 0 }
    let ripples: Ripple[] = []
    let raf = 0
    let last = performance.now()
    let idleFrames = 0

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2)
      W = window.innerWidth
      H = window.innerHeight
      canvas.width = Math.round(W * dpr)
      canvas.height = Math.round(H * dpr)
      canvas.style.width = W + "px"
      canvas.style.height = H + "px"
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      step = W < 640 ? Math.round(spacing * 0.75) : spacing
      cols = Math.ceil(W / step) + 2
      rows = Math.ceil(H / step) + 2
      ox = ((W % step) - step) / 2
      oy = ((H % step) - step) / 2
      wake()
    }

    // positions + glow of every grid point this frame
    let px = new Float32Array(0)
    let py = new Float32Array(0)
    let pi = new Float32Array(0)

    const compute = (now: number) => {
      const n = cols * rows
      if (px.length !== n) {
        px = new Float32Array(n)
        py = new Float32Array(n)
        pi = new Float32Array(n)
      }
      const s2 = 2 * (radius * 0.55) ** 2
      for (let j = 0; j < rows; j++) {
        for (let i = 0; i < cols; i++) {
          const k = j * cols + i
          const bx = ox + i * step
          const by = oy + j * step
          let dx = 0
          let dy = 0
          let glow = 0

          // pull toward the pointer
          if (ptr.on > 0.001) {
            const vx = ptr.x - bx
            const vy = ptr.y - by
            const f = Math.exp(-(vx * vx + vy * vy) / s2) * ptr.on
            dx += vx * f * pull
            dy += vy * f * pull
            glow += f
          }

          // ripples push outward as a ring
          for (const rp of ripples) {
            const age = (now - rp.t) / 1000
            const ringR = age * 520
            const vx = bx - rp.x
            const vy = by - rp.y
            const d = Math.sqrt(vx * vx + vy * vy) || 1
            const band = Math.exp(-((d - ringR) ** 2) / (2 * 34 * 34))
            const fade = Math.max(0, 1 - age / 1.6)
            const amp = band * fade * 16
            dx += (vx / d) * amp
            dy += (vy / d) * amp
            glow += band * fade * 0.9
          }

          px[k] = bx + dx
          py[k] = by + dy
          pi[k] = Math.min(1, glow)
        }
      }
    }

    const draw = (now: number) => {
      ctx.clearRect(0, 0, W, H)
      compute(now)
      ctx.lineCap = "round"

      // base grid
      ctx.lineWidth = 1
      ctx.strokeStyle = rgba(lineOpacity)
      ctx.beginPath()
      for (let j = 0; j < rows; j++) {
        for (let i = 0; i < cols; i++) {
          const k = j * cols + i
          if (i === 0) ctx.moveTo(px[k], py[k])
          else ctx.lineTo(px[k], py[k])
        }
      }
      for (let i = 0; i < cols; i++) {
        for (let j = 0; j < rows; j++) {
          const k = j * cols + i
          if (j === 0) ctx.moveTo(px[k], py[k])
          else ctx.lineTo(px[k], py[k])
        }
      }
      ctx.stroke()

      // lit segments near the pointer / ripples
      ctx.save()
      ctx.shadowColor = rgba(0.55)
      ctx.shadowBlur = 10
      const seg = (a: number, c: number) => {
        const t = (pi[a] + pi[c]) / 2
        if (t < 0.06) return
        ctx.strokeStyle = rgba(Math.min(0.95, lineOpacity + t * 0.85))
        ctx.lineWidth = 1 + t * 1.4
        ctx.beginPath()
        ctx.moveTo(px[a], py[a])
        ctx.lineTo(px[c], py[c])
        ctx.stroke()
      }
      for (let j = 0; j < rows; j++) {
        for (let i = 0; i < cols; i++) {
          const k = j * cols + i
          if (i < cols - 1) seg(k, k + 1)
          if (j < rows - 1) seg(k, k + cols)
        }
      }
      ctx.restore()

      // dots at the intersections
      for (let k = 0; k < px.length; k++) {
        const t = pi[k]
        ctx.fillStyle = rgba(Math.min(1, lineOpacity * 1.8 + t * 0.9))
        const rad = 1.4 + t * 2.6
        if (t > 0.15) {
          ctx.save()
          ctx.shadowColor = rgba(0.6)
          ctx.shadowBlur = 12 * t
          ctx.beginPath()
          ctx.arc(px[k], py[k], rad, 0, Math.PI * 2)
          ctx.fill()
          ctx.restore()
        } else {
          ctx.beginPath()
          ctx.arc(px[k], py[k], rad, 0, Math.PI * 2)
          ctx.fill()
        }
      }

      // faint lens ring around the pointer
      if (ptr.on > 0.05) {
        ctx.strokeStyle = rgba(0.12 * ptr.on)
        ctx.lineWidth = 1
        ctx.beginPath()
        ctx.arc(ptr.x, ptr.y, radius * 1.15, 0, Math.PI * 2)
        ctx.stroke()
      }
    }

    const frame = (now: number) => {
      raf = 0
      const dt = Math.min(0.05, (now - last) / 1000)
      last = now
      const ease = 1 - Math.exp(-dt * 12)
      ptr.x += (target.x - ptr.x) * ease
      ptr.y += (target.y - ptr.y) * ease
      const want = target.x > -9000 ? 1 : 0
      ptr.on += (want - ptr.on) * (1 - Math.exp(-dt * 6))
      ripples = ripples.filter((rp) => now - rp.t < 1600)

      draw(now)

      const moving = Math.abs(target.x - ptr.x) + Math.abs(target.y - ptr.y) > 0.3 || Math.abs(want - ptr.on) > 0.003
      idleFrames = moving || ripples.length ? 0 : idleFrames + 1
      if (idleFrames < 3) raf = requestAnimationFrame(frame)
    }

    function wake() {
      if (reduce) {
        draw(performance.now())
        return
      }
      idleFrames = 0
      if (!raf) {
        last = performance.now()
        raf = requestAnimationFrame(frame)
      }
    }

    const onMove = (e: PointerEvent) => {
      if (target.x < -9000) {
        ptr.x = e.clientX
        ptr.y = e.clientY
      }
      target.x = e.clientX
      target.y = e.clientY
      wake()
    }
    const onLeave = () => {
      target.x = -9999
      target.y = -9999
      wake()
    }
    const onDown = (e: PointerEvent) => {
      ripples.push({ x: e.clientX, y: e.clientY, t: performance.now() })
      if (ripples.length > 6) ripples.shift()
      if (e.pointerType !== "mouse") onMove(e)
      wake()
    }
    const onUp = (e: PointerEvent) => {
      if (e.pointerType !== "mouse") onLeave()
    }

    resize()
    window.addEventListener("resize", resize)
    window.addEventListener("pointermove", onMove, { passive: true })
    window.addEventListener("pointerdown", onDown, { passive: true })
    window.addEventListener("pointerup", onUp, { passive: true })
    document.documentElement.addEventListener("pointerleave", onLeave)
    window.addEventListener("blur", onLeave)

    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener("resize", resize)
      window.removeEventListener("pointermove", onMove)
      window.removeEventListener("pointerdown", onDown)
      window.removeEventListener("pointerup", onUp)
      document.documentElement.removeEventListener("pointerleave", onLeave)
      window.removeEventListener("blur", onLeave)
    }
  }, [spacing, color, lineOpacity, radius, pull])

  return (
    <canvas
      ref={ref}
      aria-hidden
      className={["pointer-events-none fixed inset-0 -z-10 block", className].filter(Boolean).join(" ")}
    />
  )
}
