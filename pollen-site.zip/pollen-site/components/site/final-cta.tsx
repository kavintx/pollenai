import { HexPattern } from "./logo"
import { WaitlistForm } from "./waitlist"

export function FinalCta() {
  return (
    <section className="px-3 pb-[clamp(56px,7vw,96px)]">
      <div className="relative overflow-hidden rounded-[36px] bg-white">
        <HexPattern id="hex-cta" stroke="#9be57a" opacity={0.45} />
        <div className="relative mx-auto flex max-w-[1240px] flex-col items-center gap-5 px-[clamp(18px,4vw,40px)] py-[clamp(48px,8vw,112px)] text-center">
          <h2 className="extra-wide m-0 font-display text-[clamp(46px,8.4vw,124px)] leading-[.88] font-black tracking-[-0.05em] text-balance text-ink">
            Get in line.
            <br />
            Get paid.
          </h2>
          <p className="m-0 max-w-[520px] text-[clamp(17px,1.6vw,20px)] leading-normal font-semibold text-[#2e420b]">
            Refer friends to move up the line. The earlier you&apos;re in, the sooner you start earning.
          </p>
          <WaitlistForm id="final-email" className="w-full max-w-[560px] text-left" compact />
        </div>
      </div>
    </section>
  )
}
