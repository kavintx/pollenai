import { cn } from "@/lib/utils"

/** The Pollen mark: stacked panels on a rounded tile. */
export function LogoMark({
  className,
  tile = "#ffffff",
  panels = ["#c4f5a4", "#93de6b", "#4fae2a"],
  title,
}: {
  className?: string
  tile?: string
  panels?: [string, string, string]
  title?: string
}) {
  return (
    <svg viewBox="0 0 120 120" className={className} role={title ? "img" : undefined} aria-label={title} aria-hidden={title ? undefined : true}>
      <rect x="2" y="2" width="116" height="116" rx="32" fill={tile} />
      <rect x="24" y="44" width="18" height="32" rx="7" fill={panels[0]} />
      <rect x="36" y="35" width="22" height="50" rx="8" fill={panels[1]} />
      <path d="M60 22H90a7 7 0 0 1 7 7V91a7 7 0 0 1-7 7H60a7 7 0 0 1-7-7V75L69 60 53 45V29a7 7 0 0 1 7-7Z" fill={panels[2]} />
    </svg>
  )
}

export function Wordmark({ className }: { className?: string }) {
  return (
    <span className={cn("flex items-center gap-2.5", className)}>
      <LogoMark className="size-10" />
      <span className="extra-wide font-display text-2xl font-black tracking-[-0.03em] text-ink-2">pollen</span>
    </span>
  )
}

/** Faint honeycomb texture used behind big blocks. */
export function HexPattern({ id, stroke = "#ffffff", opacity = 0.38 }: { id: string; stroke?: string; opacity?: number }) {
  return (
    <svg aria-hidden className="pointer-events-none absolute inset-0 size-full">
      <defs>
        <pattern id={id} width="56" height="97" patternUnits="userSpaceOnUse">
          <path d="M28 0 56 16.2V48.5L28 64.7 0 48.5V16.2ZM28 64.7V97" fill="none" stroke={stroke} strokeOpacity={opacity} strokeWidth="1.5" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill={`url(#${id})`} />
    </svg>
  )
}

/** Small white uppercase label above section headings. */
export function Eyebrow({ children }: { children: React.ReactNode }) {
  return (
    <span className="self-start rounded-full bg-white px-3 py-1.5 font-mono text-xs uppercase tracking-[.08em] text-ink-2">
      {children}
    </span>
  )
}

export function SectionTitle({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <h2 className={cn("wide m-0 font-display text-[clamp(40px,6vw,80px)] leading-[.95] font-black tracking-[-0.04em] text-ink", className)}>
      {children}
    </h2>
  )
}
