"use client"

import * as React from "react"
import { AudioLines, Video } from "lucide-react"

type Rate = { task: string; pay: string; note?: string }

const RATES: Record<"video" | "audio", Rate[]> = {
  video: [
    { task: "10–15 sec of head turns, expression changes or lighting variations", pay: "$0.75 – $1.25", note: "Face · opt-in" },
    { task: "30–60 sec holding objects, unboxing or hand gestures", pay: "$1.75 – $2.50" },
    { task: "1–2 min scanning a room, kitchen or walking path", pay: "$3.00 – $5.00" },
    { task: "3–5 min POV activity — cooking, fixing a bike, using tools", pay: "$8.00 – $12.00" },
  ],
  audio: [
    { task: "30–60 sec reading assigned text or commands", pay: "$0.35 – $0.50", note: "Voice · opt-in" },
    { task: "2–3 min reading a passage or answering a prompt", pay: "$1.25 – $1.75", note: "Voice · opt-in" },
    { task: "2–3 min clips in underrepresented accents or languages", pay: "$1.75 – $2.50", note: "Voice · opt-in" },
    { task: "10–15 min two-person call (customer service, casual chat)", pay: "$6.00 – $10.00", note: "Per person · voice · opt-in" },
  ],
}

const TABS = [
  { id: "video" as const, label: "Video", icon: Video },
  { id: "audio" as const, label: "Audio", icon: AudioLines },
]

export function PayRates() {
  const [tab, setTab] = React.useState<"video" | "audio">("video")
  const rows = RATES[tab]

  return (
    <div className="flex flex-col gap-4 rounded-[30px] border border-[rgba(36,53,10,.08)] bg-white p-[clamp(20px,3vw,36px)] shadow-[0_18px_40px_rgba(45,69,0,.07)]">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <span className="text-[15px] font-semibold text-moss">What a shot-list task pays</span>
        <div role="tablist" aria-label="Task type" className="flex gap-1 rounded-full bg-[#eef6d6] p-1">
          {TABS.map(({ id, label, icon: Icon }) => {
            const on = tab === id
            return (
              <button
                key={id}
                role="tab"
                type="button"
                aria-selected={on}
                aria-controls="pay-rates-panel"
                onClick={() => setTab(id)}
                className={`inline-flex min-h-10 cursor-pointer items-center gap-2 rounded-full px-4 text-sm font-bold transition ${
                  on ? "bg-forest text-lime" : "text-ink-2 hover:bg-white/70"
                }`}
              >
                <Icon className="size-4" aria-hidden />
                {label}
              </button>
            )
          })}
        </div>
      </div>

      <ul id="pay-rates-panel" role="tabpanel" className="m-0 flex list-none flex-col p-0">
        {rows.map((r, i) => (
          <li
            key={r.task}
            className={`flex flex-wrap items-center justify-between gap-x-6 gap-y-2 py-4 ${i ? "border-t border-[rgba(36,53,10,.08)]" : ""}`}
          >
            <div className="flex min-w-0 flex-[1_1_320px] flex-col gap-1.5">
              <span className="text-base leading-snug font-semibold text-ink-2">{r.task}</span>
              {r.note ? (
                <span className="self-start rounded-full bg-[#f4fadf] px-2.5 py-0.5 font-mono text-[11px] tracking-[.04em] text-moss uppercase">
                  {r.note}
                </span>
              ) : null}
            </div>
            <span className="extra-wide shrink-0 rounded-2xl bg-lime px-4 py-2 font-display text-[clamp(18px,2vw,24px)] font-black tracking-[-0.02em] text-ink">
              {r.pay}
            </span>
          </li>
        ))}
      </ul>

      <p className="m-0 text-[13px] leading-normal text-moss-2">
        Estimated payout per approved task. Final rates are set at launch and can change with demand. Earnings aren&apos;t
        guaranteed.
      </p>
    </div>
  )
}
