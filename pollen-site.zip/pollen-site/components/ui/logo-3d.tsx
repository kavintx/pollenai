"use client"

import * as React from "react"
import * as THREE from "three"
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js"

/*
 * Logo3D — the Pollen mark as a real 3D object. The three panels float in front
 * of the tile and tilt toward the cursor (drag on touch). Hovering pulls the
 * layers apart; clicking fans them out like photos being dealt, then they
 * spring back. Pauses when off-screen; holds still with reduced motion.
 */

export type Logo3DProps = {
  className?: string
  tile?: string
  panels?: [string, string, string]
  /** Called once if WebGL isn't available, so the parent can show a fallback. */
  onUnsupported?: () => void
}

// The SVG logo lives in a 120×120 box; map it to a ~3 unit wide 3D space.
const S = 40
const P = (x: number, y: number): [number, number] => [(x - 60) / S, (60 - y) / S]

function roundedRect(x: number, y: number, w: number, h: number, r: number) {
  const s = new THREE.Shape()
  s.moveTo(...P(x + r, y))
  s.lineTo(...P(x + w - r, y))
  s.quadraticCurveTo(...P(x + w, y), ...P(x + w, y + r))
  s.lineTo(...P(x + w, y + h - r))
  s.quadraticCurveTo(...P(x + w, y + h), ...P(x + w - r, y + h))
  s.lineTo(...P(x + r, y + h))
  s.quadraticCurveTo(...P(x, y + h), ...P(x, y + h - r))
  s.lineTo(...P(x, y + r))
  s.quadraticCurveTo(...P(x, y), ...P(x + r, y))
  return s
}

function frontPanel() {
  // the big panel with the chevron notch on its left edge
  const s = new THREE.Shape()
  s.moveTo(...P(60, 22))
  s.lineTo(...P(90, 22))
  s.quadraticCurveTo(...P(97, 22), ...P(97, 29))
  s.lineTo(...P(97, 91))
  s.quadraticCurveTo(...P(97, 98), ...P(90, 98))
  s.lineTo(...P(60, 98))
  s.quadraticCurveTo(...P(53, 98), ...P(53, 91))
  s.lineTo(...P(53, 75))
  s.lineTo(...P(69, 60))
  s.lineTo(...P(53, 45))
  s.lineTo(...P(53, 29))
  s.quadraticCurveTo(...P(53, 22), ...P(60, 22))
  return s
}

function extrude(shape: THREE.Shape, depth: number, bevel: number) {
  const g = new THREE.ExtrudeGeometry(shape, {
    depth,
    bevelEnabled: true,
    bevelThickness: bevel,
    bevelSize: bevel,
    bevelSegments: 5,
    curveSegments: 18,
  })
  g.translate(0, 0, -depth / 2)
  g.computeVertexNormals()
  return g
}

export default function Logo3D({
  className,
  tile = "#ffffff",
  panels = ["#c4f5a4", "#93de6b", "#4fae2a"],
  onUnsupported,
}: Logo3DProps) {
  const hostRef = React.useRef<HTMLDivElement>(null)

  React.useEffect(() => {
    const host = hostRef.current
    if (!host) return

    let renderer: THREE.WebGLRenderer
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" })
    } catch {
      onUnsupported?.()
      return
    }
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches

    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2))
    renderer.outputColorSpace = THREE.SRGBColorSpace
    renderer.toneMapping = THREE.NeutralToneMapping
    renderer.toneMappingExposure = 1
    renderer.domElement.style.width = "100%"
    renderer.domElement.style.height = "100%"
    renderer.domElement.style.display = "block"
    renderer.domElement.style.touchAction = "pan-y"
    host.appendChild(renderer.domElement)

    const scene = new THREE.Scene()
    const pmrem = new THREE.PMREMGenerator(renderer)
    const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture
    scene.environment = envTex
    scene.environmentIntensity = 0.55

    const camera = new THREE.PerspectiveCamera(30, 1, 0.1, 100)
    camera.position.set(0, 0, 7.4)

    // lights: soft white key, lime fill from below, rim from behind
    scene.add(new THREE.HemisphereLight(0xffffff, 0xccf056, 0.45))
    const key = new THREE.DirectionalLight(0xffffff, 1.3)
    key.position.set(3, 4, 6)
    scene.add(key)
    const fill = new THREE.DirectionalLight(0xd9ff7a, 0.8)
    fill.position.set(-4, -3, 3)
    scene.add(fill)
    const rim = new THREE.DirectionalLight(0xffffff, 1.2)
    rim.position.set(0, 2, -5)
    scene.add(rim)

    // geometry + materials
    const root = new THREE.Group()
    scene.add(root)

    const tileGeo = extrude(roundedRect(2, 2, 116, 116, 32), 0.22, 0.06)
    const tileMat = new THREE.MeshPhysicalMaterial({
      color: tile,
      roughness: 0.32,
      metalness: 0,
      clearcoat: 1,
      clearcoatRoughness: 0.18,
      sheen: 0.4,
      sheenColor: new THREE.Color("#eaffc0"),
    })
    const tileMesh = new THREE.Mesh(tileGeo, tileMat)
    root.add(tileMesh)

    const panelGeos = [
      extrude(roundedRect(24, 44, 18, 32, 7), 0.1, 0.035),
      extrude(roundedRect(36, 35, 22, 50, 8), 0.1, 0.035),
      extrude(frontPanel(), 0.12, 0.04),
    ]
    const panelMats = panels.map(
      (c, i) =>
        new THREE.MeshPhysicalMaterial({
          color: c,
          roughness: i === 2 ? 0.3 : 0.18,
          metalness: 0,
          clearcoat: 1,
          clearcoatRoughness: 0.1,
          // the back two are frosted glass, the front one solid
          transmission: i === 2 ? 0 : 0.2,
          thickness: 0.35,
          ior: 1.4,
          transparent: i !== 2,
          opacity: i === 2 ? 1 : 0.96,
        }),
    )
    const panelMeshes = panelGeos.map((g, i) => {
      const m = new THREE.Mesh(g, panelMats[i])
      root.add(m)
      return m
    })

    // sizing
    const resize = () => {
      const r = host.getBoundingClientRect()
      const w = Math.max(1, r.width)
      const h = Math.max(1, r.height)
      renderer.setSize(w, h, false)
      camera.aspect = w / h
      camera.updateProjectionMatrix()
      if (reduce) render(performance.now())
    }
    const ro = new ResizeObserver(resize)
    ro.observe(host)

    // interaction state
    const tilt = { x: 0, y: 0, tx: 0, ty: 0 }
    let hover = 0
    let hoverTarget = 0
    let fan = 0
    let fanV = 0
    let drag: { x: number; y: number; bx: number; by: number } | null = null

    const onWindowMove = (e: PointerEvent) => {
      if (e.pointerType !== "mouse") return
      const r = host.getBoundingClientRect()
      const cx = r.left + r.width / 2
      const cy = r.top + r.height / 2
      const span = Math.max(420, r.width)
      tilt.tx = THREE.MathUtils.clamp((e.clientX - cx) / span, -1, 1)
      tilt.ty = THREE.MathUtils.clamp((e.clientY - cy) / span, -1, 1)
      const inside = e.clientX > r.left - 60 && e.clientX < r.right + 60 && e.clientY > r.top - 60 && e.clientY < r.bottom + 60
      hoverTarget = inside ? 1 : 0
    }
    const onDown = (e: PointerEvent) => {
      fanV += 11 // deal the panels out
      if (e.pointerType !== "mouse") {
        drag = { x: e.clientX, y: e.clientY, bx: tilt.tx, by: tilt.ty }
        hoverTarget = 1
      }
    }
    const onMove = (e: PointerEvent) => {
      if (!drag) return
      tilt.tx = THREE.MathUtils.clamp(drag.bx + (e.clientX - drag.x) / 160, -1.2, 1.2)
      tilt.ty = THREE.MathUtils.clamp(drag.by + (e.clientY - drag.y) / 220, -1, 1)
    }
    const onUp = () => {
      if (!drag) return
      drag = null
      tilt.tx = 0
      tilt.ty = 0
      hoverTarget = 0
    }
    const onLeave = () => {
      tilt.tx = 0
      tilt.ty = 0
      hoverTarget = 0
    }

    const canvas = renderer.domElement
    canvas.style.cursor = "pointer"
    window.addEventListener("pointermove", onWindowMove, { passive: true })
    canvas.addEventListener("pointerdown", onDown)
    window.addEventListener("pointermove", onMove, { passive: true })
    window.addEventListener("pointerup", onUp)
    window.addEventListener("pointercancel", onUp)
    document.documentElement.addEventListener("pointerleave", onLeave)

    // frame
    let raf = 0
    let last = performance.now()
    let visible = true
    const BASE = [0.16, 0.34, 0.54]
    const SPREAD = [0.18, 0.34, 0.55]

    function render(now: number) {
      const dt = Math.min(0.05, (now - last) / 1000)
      last = now
      const t = now / 1000
      const k = 1 - Math.exp(-dt * 6)

      tilt.x += (tilt.tx - tilt.x) * k
      tilt.y += (tilt.ty - tilt.y) * k
      hover += (hoverTarget - hover) * (1 - Math.exp(-dt * 5))

      // springy fan-out
      fanV += (-70 * fan - 9 * fanV) * dt
      fan += fanV * dt

      const idle = reduce ? 0 : 1
      root.rotation.y = -0.32 + tilt.x * 0.65 + Math.sin(t * 0.6) * 0.07 * idle
      root.rotation.x = 0.12 + tilt.y * 0.45 + Math.cos(t * 0.5) * 0.05 * idle
      root.rotation.z = -0.05 + Math.sin(t * 0.4) * 0.02 * idle
      root.position.y = Math.sin(t * 1.1) * 0.07 * idle

      panelMeshes.forEach((m, i) => {
        m.position.z = BASE[i] + SPREAD[i] * hover + Math.abs(fan) * 0.12 * (i + 1)
        m.position.x = fan * [-0.55, -0.28, 0.18][i]
        m.position.y = fan * [0.08, 0.04, -0.03][i]
        m.rotation.z = fan * [0.32, 0.16, -0.06][i]
        m.rotation.y = tilt.x * 0.08 * (i + 1) * hover
      })

      renderer.render(scene, camera)
    }

    const loop = (now: number) => {
      raf = 0
      if (!visible || document.hidden) return
      render(now)
      raf = requestAnimationFrame(loop)
    }
    const start = () => {
      if (reduce || raf) return
      last = performance.now()
      raf = requestAnimationFrame(loop)
    }

    const io = new IntersectionObserver(([e]) => {
      visible = e.isIntersecting
      if (visible) start()
    })
    io.observe(host)
    const onVis = () => !document.hidden && start()
    document.addEventListener("visibilitychange", onVis)

    resize()
    if (reduce) render(performance.now())
    else start()

    return () => {
      cancelAnimationFrame(raf)
      io.disconnect()
      ro.disconnect()
      document.removeEventListener("visibilitychange", onVis)
      window.removeEventListener("pointermove", onWindowMove)
      canvas.removeEventListener("pointerdown", onDown)
      window.removeEventListener("pointermove", onMove)
      window.removeEventListener("pointerup", onUp)
      window.removeEventListener("pointercancel", onUp)
      document.documentElement.removeEventListener("pointerleave", onLeave)
      ;[tileGeo, ...panelGeos].forEach((g) => g.dispose())
      ;[tileMat, ...panelMats].forEach((m) => m.dispose())
      envTex.dispose()
      pmrem.dispose()
      renderer.dispose()
      canvas.remove()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tile, panels.join(",")])

  return <div ref={hostRef} className={className} role="img" aria-label="Pollen logo in 3D" />
}
