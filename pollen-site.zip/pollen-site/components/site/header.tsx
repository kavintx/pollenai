import { Wordmark } from "./logo"

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-20 border-b border-[rgba(36,53,10,.12)] bg-[rgba(204,240,86,.84)] backdrop-blur-lg">
      <div className="mx-auto flex max-w-[1240px] items-center justify-between gap-4 px-5 py-3">
        <a href="/#top" aria-label="Pollen home">
          <Wordmark />
        </a>
        <a
          href="/#join"
          className="inline-flex min-h-11 items-center rounded-full bg-forest px-[18px] text-[15px] font-bold text-lime transition hover:-translate-y-0.5 hover:shadow-[0_10px_24px_rgba(45,69,0,.25)]"
        >
          Join the waitlist
        </a>
      </div>
    </header>
  )
}
