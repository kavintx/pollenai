"use client"

import * as React from "react"
import { Plus } from "lucide-react"
import { Eyebrow, SectionTitle } from "./logo"

const FAQS = [
  {
    q: "Who buys the data?",
    a: "AI companies and research labs that need real-world video, photos and audio to train and test their models. We'll name launch partners as deals are signed: [PARTNER NAMES].",
  },
  {
    q: "What do I take pictures of?",
    a: "Whatever's on your shot list. The app shows what AI companies are asking for right now — specific videos, scenes, objects and sounds — so you're not guessing. Everything has to be real and shot by you: no AI-generated images and no filler like blank walls.",
  },
  {
    q: "How much do I earn?",
    a: "Each task shows its pay up front. Right now that's roughly $0.35–$0.50 for a 30–60 sec voice clip, up to $8–$12 for a 3–5 min POV video — video pays the most. Rates are estimates until launch and can change with demand, and nothing is guaranteed.",
  },
  {
    q: "Is my data safe?",
    a: "You decide what's for sale, file by file. Faces and voices are never sold without your explicit opt-in, and you can delete files or your account anytime.",
  },
  {
    q: "When do you launch?",
    a: "No date yet — we're building it now. Waitlist members get in first, and we'll email you the moment it's your turn. The higher you are on the list, the sooner you're in.",
  },
]

export function Faq() {
  const [open, setOpen] = React.useState(0)
  return (
    <section className="px-5 pb-[clamp(72px,9vw,128px)]">
      <div className="mx-auto grid max-w-[1240px] grid-cols-[repeat(auto-fit,minmax(min(380px,100%),1fr))] items-start gap-[clamp(28px,5vw,72px)]">
        <div className="flex flex-col gap-3.5">
          <Eyebrow>FAQ</Eyebrow>
          <SectionTitle>Fair questions.</SectionTitle>
        </div>
        <div className="flex flex-col gap-2.5">
          {FAQS.map((f, i) => {
            const isOpen = open === i
            const id = `faq-${i}`
            return (
              <div key={f.q} className="rounded-[22px] border border-[rgba(36,53,10,.08)] bg-white px-5">
                <h3 className="m-0">
                  <button
                    type="button"
                    aria-expanded={isOpen}
                    aria-controls={id}
                    onClick={() => setOpen(isOpen ? -1 : i)}
                    className="flex min-h-18 w-full cursor-pointer items-center justify-between gap-4 py-[18px] text-left text-[clamp(17px,2vw,21px)] font-extrabold text-ink"
                  >
                    {f.q}
                    <span
                      className={`grid size-9 shrink-0 place-items-center rounded-full text-ink-2 transition-transform duration-300 ${
                        isOpen ? "rotate-45 bg-lime" : "bg-[#eef6d6]"
                      }`}
                    >
                      <Plus className="size-4" strokeWidth={2.6} aria-hidden />
                    </span>
                  </button>
                </h3>
                <div
                  id={id}
                  className={`grid transition-[grid-template-rows] duration-300 ${isOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]"}`}
                >
                  <div className="overflow-hidden">
                    <p className="m-0 pr-11 pb-[22px] text-base leading-relaxed text-moss">{f.a}</p>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
