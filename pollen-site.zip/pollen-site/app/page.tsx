import { SiteHeader } from "@/components/site/header"
import { Hero } from "@/components/site/hero"
import { OnTheLine } from "@/components/site/on-the-line"
import { Earnings, HowItWorks, Marquee, RealShotsOnly, Trust, WhatYouCanSell } from "@/components/site/sections"
import { Faq } from "@/components/site/faq"
import { FinalCta } from "@/components/site/final-cta"
import { SiteFooter } from "@/components/site/footer"
import { WaitlistProvider } from "@/components/site/waitlist"

export default function Home() {
  return (
    <WaitlistProvider>
      <SiteHeader />
      <main>
        <Hero />
        <Marquee />
        <OnTheLine />
        <HowItWorks />
        <WhatYouCanSell />
        <RealShotsOnly />
        <Trust />
        <Earnings />
        <Faq />
        <FinalCta />
      </main>
      <SiteFooter />
    </WaitlistProvider>
  )
}
