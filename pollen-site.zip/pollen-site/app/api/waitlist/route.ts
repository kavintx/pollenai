import { NextResponse } from "next/server"
import { waitlist } from "@/lib/waitlist-store"

export const dynamic = "force-dynamic"

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const REF_RE = /^[A-Z0-9]{4,12}$/

/** Current number of people on the waitlist. */
export async function GET() {
  try {
    const count = await waitlist.count()
    return NextResponse.json({ count })
  } catch (err) {
    console.error(err)
    return NextResponse.json({ count: null }, { status: 200 })
  }
}

/** Join the waitlist: { email, ref? } → { position, refCode, referrals, alreadyJoined } */
export async function POST(req: Request) {
  let body: { email?: unknown; ref?: unknown; isAdult?: unknown }
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 })
  }

  const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : ""
  if (!EMAIL_RE.test(email) || email.length > 254) {
    return NextResponse.json({ error: "Enter a valid email to save your spot." }, { status: 400 })
  }
  if (body.isAdult !== true) {
    return NextResponse.json(
      { error: "Pollen is 18+ only. Tick the box to confirm you're 18 or older." },
      { status: 400 },
    )
  }
  const refRaw = typeof body.ref === "string" ? body.ref.trim().toUpperCase() : ""
  const ref = REF_RE.test(refRaw) ? refRaw : null

  try {
    const result = await waitlist.join(email, ref)
    return NextResponse.json(result)
  } catch (err) {
    console.error(err)
    return NextResponse.json({ error: "Something went wrong. Try again in a sec." }, { status: 500 })
  }
}
