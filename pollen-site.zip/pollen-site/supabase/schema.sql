-- Pollen waitlist table. Run this once in Supabase → SQL Editor.
create table if not exists public.waitlist (
  id          bigint generated always as identity primary key,
  email       text not null unique,
  ref_code    text not null unique,
  referred_by text references public.waitlist (ref_code) on delete set null,
  created_at  timestamptz not null default now()
);

create index if not exists waitlist_referred_by_idx on public.waitlist (referred_by);

-- Lock the table down: only the server (service role key) can read/write.
alter table public.waitlist enable row level security;
