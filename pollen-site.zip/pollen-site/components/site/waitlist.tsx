"use client"

import * as React from "react"
import { Check, Copy, Loader2 } from "lucide-react"
import { cn } from "@/lib/utils"
import { RainbowButton } from "@/components/ui/rainbow-button"

// Pollen's forest green inside the rainbow border (overrides the component's default black/white fill).
// Class names are written out in full so Tailwind can detect them.
const SIGNUP_BUTTON = cn(
  "h-auto min-h-14 flex-[1_0_auto] rounded-2xl px-6 text-[17px] font-extrabold transition hover:-translate-y-0.5 focus-visible:ring-2 focus-visible:ring-offset-2",
  "bg-[linear-gradient(#2d4500,#2d4500),linear-gradient(#2d4500_50%,rgba(45,69,0,0.6)_80%,rgba(45,69,0,0)),linear-gradient(90deg,hsl(var(--color-1)),hsl(var(--color-5)),hsl(var(--color-3)),hsl(var(--color-4)),hsl(var(--color-2)))]",
  "dark:bg-[linear-gradient(#2d4500,#2d4500),linear-gradient(#2d4500_50%,rgba(45,69,0,0.6)_80%,rgba(45,69,0,0)),linear-gradient(90deg,hsl(var(--color-1)),hsl(var(--color-5)),hsl(var(--color-3)),hsl(var(--color-4)),hsl(var(--color-2)))]",
)

type Joined = { position: number; refCode: string; referrals: number; alreadyJoined: boolean }

type WaitlistState = {
  count: number | null
  joined: Joined | null
  join: (email: string) => Promise<string | null>
}

const WaitlistContext = React.createContext<WaitlistState | null>(null)

const STORAGE_KEY = "pollen-waitlist"

export function WaitlistProvider({ children }: { children: React.ReactNode }) {
  const [count, setCount] = React.useState<number | null>(null)
  const [joined, setJoined] = React.useState<Joined | null>(null)
  const refFromUrl = React.useRef<string | null>(null)

  React.useEffect(() => {
    refFromUrl.current = new URLSearchParams(window.location.search).get("ref")
    try {
      const saved = localStorage.getItem(STORAGE_KEY)
      if (saved) setJoined(JSON.parse(saved))
    } catch {}

    let alive = true
    const load = () =>
      fetch("/api/waitlist", { cache: "no-store" })
        .then((r) => r.json())
        .then((d) => alive && typeof d.count === "number" && setCount(d.count))
        .catch(() => {})
    load()
    const t = window.setInterval(load, 20000)
    return () => {
      alive = false
      window.clearInterval(t)
    }
  }, [])

  const join = React.useCallback(async (email: string) => {
    const res = await fetch("/api/waitlist", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, ref: refFromUrl.current }),
    })
    const data = await res.json().catch(() => ({}))
    if (!res.ok) return (data.error as string) || "Something went wrong. Try again in a sec."
    setJoined(data)
    if (!data.alreadyJoined) setCount((c) => (c == null ? c : c + 1))
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data))
    } catch {}
    return null
  }, [])

  return <WaitlistContext.Provider value={{ count, joined, join }}>{children}</WaitlistContext.Provider>
}

export function useWaitlist() {
  const ctx = React.useContext(WaitlistContext)
  if (!ctx) throw new Error("useWaitlist must be used inside <WaitlistProvider>")
  return ctx
}

export function WaitlistCount({ className }: { className?: string }) {
  const { count } = useWaitlist()
  if (count == null || count < 1) return <span className={className}>Waitlist is open</span>
  return (
    <span className={className}>
      <strong className="font-medium">{count.toLocaleString("en-US")}</strong> already in line
    </span>
  )
}

/** Email field + button, or the "You're #N" card once joined. */
export function WaitlistForm({ id, className, compact }: { id: string; className?: string; compact?: boolean }) {
  const { joined, join } = useWaitlist()
  const [email, setEmail] = React.useState("")
  const [error, setError] = React.useState<string | null>(null)
  const [pending, setPending] = React.useState(false)

  if (joined) return <JoinedCard joined={joined} className={className} compact={compact} />

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setError("Enter a valid email to save your spot.")
      return
    }
    setPending(true)
    setError(null)
    const err = await join(email.trim())
    setPending(false)
    if (err) setError(err)
  }

  return (
    <div className={cn("flex flex-col gap-3", className)}>
      <form
        onSubmit={onSubmit}
        noValidate
        className="flex flex-wrap gap-1.5 rounded-[22px] bg-white p-1.5 shadow-[0_12px_32px_rgba(45,69,0,.14)] transition-shadow focus-within:shadow-[0_0_0_4px_rgba(45,69,0,.18)]"
      >
        <label htmlFor={id} className="sr-only">
          Email address
        </label>
        <input
          id={id}
          type="email"
          autoComplete="email"
          inputMode="email"
          placeholder="you@email.com"
          value={email}
          onChange={(e) => {
            setEmail(e.target.value)
            setError(null)
          }}
          aria-invalid={Boolean(error)}
          aria-describedby={error ? id + "-error" : undefined}
          className="min-h-14 min-w-0 flex-[999_1_220px] bg-transparent px-4 text-[17px] font-semibold text-ink-2 outline-none placeholder:text-[#6b7a4a]"
        />
        <RainbowButton type="submit" disabled={pending} className={SIGNUP_BUTTON}>
          <span className="relative z-10 inline-flex items-center gap-2">
            {pending ? <Loader2 className="size-5 animate-spin" aria-hidden /> : null}
            Join the waitlist
          </span>
        </RainbowButton>
      </form>
      <p className="m-0 -mt-1 pl-1 text-[11px] leading-tight text-moss">
        18+ only. By joining you agree to our{" "}
        <a href="/terms" className="underline underline-offset-2 hover:text-ink-2">
          Terms
        </a>
        .
      </p>
      {error ? (
        <p id={id + "-error"} role="alert" className="self-start rounded-lg bg-white px-3 py-2 text-sm font-bold text-[#b42318]">
          {error}
        </p>
      ) : null}
    </div>
  )
}

function JoinedCard({ joined, className, compact }: { joined: Joined; className?: string; compact?: boolean }) {
  const [copied, setCopied] = React.useState(false)
  const [origin, setOrigin] = React.useState(process.env.NEXT_PUBLIC_SITE_URL || "")
  React.useEffect(() => {
    if (!process.env.NEXT_PUBLIC_SITE_URL) setOrigin(window.location.origin)
  }, [])
  const link = `${origin.replace(/\/$/, "")}/?ref=${joined.refCode}`
  const shown = link.replace(/^https?:\/\//, "")

  const copy = async () => {
    try {
      if (navigator.share && window.matchMedia("(pointer: coarse)").matches) {
        await navigator.share({ title: "Pollen", text: "Get paid for your photos — join the Pollen waitlist:", url: link })
        return
      }
      await navigator.clipboard.writeText(link)
      setCopied(true)
      window.setTimeout(() => setCopied(false), 1800)
    } catch {}
  }

  return (
    <div
      className={cn(
        "flex animate-rise flex-col gap-3.5 rounded-[26px] bg-white p-6 text-left shadow-[0_12px_32px_rgba(45,69,0,.14)]",
        className,
      )}
    >
      {!compact ? (
        <div className="flex items-center gap-2 font-mono text-xs uppercase tracking-[.06em] text-[#3d5a0e]">
          <Check className="size-4" strokeWidth={3} aria-hidden />
          {joined.alreadyJoined ? "You're already in" : "You're in"}
        </div>
      ) : null}
      <p className="wide font-display text-[clamp(30px,4.4vw,46px)] leading-none font-black tracking-[-0.035em] text-ink">
        You&apos;re{" "}
        <span className="rounded-[.12em] bg-lime px-[.1em]">#{joined.position.toLocaleString("en-US")}</span> on the
        list.
      </p>
      <p className="text-base leading-normal text-moss">
        Refer friends to move up the line. Every friend who joins with your link bumps you closer to the front.
        {joined.referrals > 0 ? ` You've brought in ${joined.referrals} so far.` : ""}
      </p>
      <div className="flex flex-wrap gap-2">
        <div className="flex min-h-13 min-w-0 flex-[999_1_220px] items-center truncate rounded-[14px] border border-[#dcebae] bg-mint px-4 font-mono text-sm text-ink-2">
          {shown}
        </div>
        <button
          type="button"
          onClick={copy}
          className="inline-flex min-h-13 flex-[1_0_auto] cursor-pointer items-center justify-center gap-2 rounded-[14px] bg-forest px-5 font-extrabold text-lime transition hover:-translate-y-0.5 focus-visible:outline-3 focus-visible:outline-offset-3 focus-visible:outline-forest"
        >
          {copied ? <Check className="size-4" aria-hidden /> : <Copy className="size-4" aria-hidden />}
          {copied ? "Copied" : "Copy link"}
        </button>
      </div>
    </div>
  )
}
