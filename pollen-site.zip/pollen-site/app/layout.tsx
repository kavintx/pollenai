import type { Metadata, Viewport } from "next"
import localFont from "next/font/local"
import KineticGrid from "@/components/ui/kinetic-grid"
import "./globals.css"

// Self-hosted (app/fonts) so builds never depend on reaching Google Fonts.
const archivo = localFont({
  src: "./fonts/archivo-variable.woff2",
  variable: "--font-archivo",
  weight: "100 900",
  display: "swap",
  declarations: [{ prop: "font-stretch", value: "62% 125%" }],
})
const manrope = localFont({ src: "./fonts/manrope-variable.woff2", variable: "--font-manrope", weight: "200 800", display: "swap" })
const jetbrains = localFont({ src: "./fonts/jetbrains-mono-500.woff2", variable: "--font-jetbrains", weight: "500", display: "swap" })

export const metadata: Metadata = {
  title: "Pollen — Get paid for your video, photos and sound",
  description:
    "AI companies need real video, photos and audio to train their models. Pollen gives you a shot list and pays you per approved task. Join the waitlist.",
  openGraph: {
    title: "Pollen — Your camera roll is worth money.",
    description: "Get paid to shoot video, photos and audio for AI companies. Join the waitlist.",
    type: "website",
  },
}

export const viewport: Viewport = {
  themeColor: "#ccf056",
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${archivo.variable} ${manrope.variable} ${jetbrains.variable}`}>
      <body className="overflow-x-hidden">
        <KineticGrid color="#2d4500" />
        {children}
      </body>
    </html>
  )
}
