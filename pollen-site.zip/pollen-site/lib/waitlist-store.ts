import "server-only"

/**
 * Waitlist storage.
 *
 * With SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY set, signups go to the
 * `waitlist` table (see supabase/schema.sql) through Supabase's REST API.
 * Without them, an in-memory store is used — fine for `npm run dev`,
 * but it resets on every deploy/cold start, so set Supabase up before launch.
 */

export type Entry = { id: number; email: string; refCode: string; referredBy: string | null }
export type JoinResult = { position: number; refCode: string; referrals: number; alreadyJoined: boolean }

/** Each friend who joins with your link moves you up this many spots. */
export const SPOTS_PER_REFERRAL = 5

const SUPABASE_URL = process.env.SUPABASE_URL?.replace(/\/$/, "")
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY

export const usingSupabase = Boolean(SUPABASE_URL && SUPABASE_KEY)

function newRefCode(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
  const bytes = crypto.getRandomValues(new Uint8Array(6))
  return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join("")
}

function displayPosition(rawPosition: number, referrals: number): number {
  return Math.max(1, rawPosition - referrals * SPOTS_PER_REFERRAL)
}

/* ------------------------------------------------------------ in-memory */

const memory: Entry[] = []

const memoryStore = {
  async count() {
    return memory.length
  },
  async join(email: string, referredBy: string | null): Promise<JoinResult> {
    let entry = memory.find((e) => e.email === email)
    const alreadyJoined = Boolean(entry)
    if (!entry) {
      const validRef = referredBy && memory.some((e) => e.refCode === referredBy) ? referredBy : null
      entry = { id: memory.length + 1, email, refCode: newRefCode(), referredBy: validRef }
      memory.push(entry)
    }
    const referrals = memory.filter((e) => e.referredBy === entry!.refCode).length
    return { position: displayPosition(entry.id, referrals), refCode: entry.refCode, referrals, alreadyJoined }
  },
}

/* ------------------------------------------------------------- supabase */

async function sb(path: string, init: RequestInit & { prefer?: string } = {}) {
  const { prefer, headers, ...rest } = init
  return fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    ...rest,
    cache: "no-store",
    headers: {
      apikey: SUPABASE_KEY!,
      Authorization: `Bearer ${SUPABASE_KEY}`,
      "Content-Type": "application/json",
      ...(prefer ? { Prefer: prefer } : {}),
      ...headers,
    },
  })
}

async function sbCount(filter: string): Promise<number> {
  const res = await sb(`waitlist?select=id${filter ? "&" + filter : ""}`, {
    method: "HEAD",
    prefer: "count=exact",
  })
  if (!res.ok) throw new Error(`Supabase count failed: ${res.status}`)
  const range = res.headers.get("content-range") ?? "*/0"
  return Number(range.split("/")[1]) || 0
}

const supabaseStore = {
  async count() {
    return sbCount("")
  },
  async join(email: string, referredBy: string | null): Promise<JoinResult> {
    const enc = encodeURIComponent
    const find = async () => {
      const res = await sb(`waitlist?select=id,ref_code&email=eq.${enc(email)}&limit=1`)
      if (!res.ok) throw new Error(`Supabase lookup failed: ${res.status}`)
      const rows = (await res.json()) as { id: number; ref_code: string }[]
      return rows[0] ?? null
    }

    let row = await find()
    const alreadyJoined = Boolean(row)

    if (!row) {
      let validRef: string | null = null
      if (referredBy) validRef = (await sbCount(`ref_code=eq.${enc(referredBy)}`)) > 0 ? referredBy : null
      const res = await sb("waitlist", {
        method: "POST",
        prefer: "return=representation",
        body: JSON.stringify({ email, ref_code: newRefCode(), referred_by: validRef }),
      })
      if (res.status === 409) {
        row = await find() // someone (probably the same person, double-clicking) beat us to it
      } else if (!res.ok) {
        throw new Error(`Supabase insert failed: ${res.status} ${await res.text()}`)
      } else {
        row = ((await res.json()) as { id: number; ref_code: string }[])[0]
      }
    }
    if (!row) throw new Error("Could not create waitlist entry")

    const [rawPosition, referrals] = await Promise.all([
      sbCount(`id=lte.${row.id}`),
      sbCount(`referred_by=eq.${enc(row.ref_code)}`),
    ])
    return { position: displayPosition(rawPosition, referrals), refCode: row.ref_code, referrals, alreadyJoined }
  },
}

export const waitlist = usingSupabase ? supabaseStore : memoryStore
