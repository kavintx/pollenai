import { AtSign, Mail } from "lucide-react"
import { Wordmark } from "./logo"

const INSTAGRAM_URL = "https://www.instagram.com/usepollenai/"
const TIKTOK_URL = "https://www.tiktok.com/@usepollenai"
const EMAIL = "contact@usepollen.ai"

export function SiteFooter() {
  return (
    <footer className="px-5 pb-12">
      <div className="mx-auto flex max-w-[1240px] flex-wrap items-start justify-between gap-8">
        <div className="flex flex-col gap-3">
          <Wordmark />
          <span className="text-sm font-medium text-moss-2">Get paid for your video, photos and sound.</span>
        </div>
        <nav aria-label="Footer" className="flex flex-wrap gap-12">
          <div className="flex flex-col gap-2.5 text-[15px] font-semibold">
            <span className="font-mono text-xs font-medium tracking-[.06em] text-moss-2 uppercase">Contact</span>
            <a
              href={INSTAGRAM_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-ink-2 no-underline hover:text-[#3d5a0e]"
            >
              <AtSign className="size-4" aria-hidden />
              usepollenai on Instagram
            </a>
            <a
              href={TIKTOK_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-ink-2 no-underline hover:text-[#3d5a0e]"
            >
              <AtSign className="size-4" aria-hidden />
              usepollenai on TikTok
            </a>
            <a href={`mailto:${EMAIL}`} className="inline-flex items-center gap-2 text-ink-2 no-underline hover:text-[#3d5a0e]">
              <Mail className="size-4" aria-hidden />
              {EMAIL}
            </a>
          </div>
          <div className="flex flex-col gap-2.5 text-[15px] font-semibold">
            <span className="font-mono text-xs font-medium tracking-[.06em] text-moss-2 uppercase">Legal</span>
            <a href="/terms" className="text-ink-2 no-underline hover:text-[#3d5a0e]">
              Terms
            </a>
            <a href="#" className="text-ink-2 no-underline hover:text-[#3d5a0e]">
              Privacy
            </a>
          </div>
        </nav>
      </div>
      <div className="mx-auto mt-8 max-w-[1240px] border-t border-[rgba(36,53,10,.12)] pt-5 text-[13px] font-medium text-moss-2">
        © {new Date().getFullYear()} Pollen. All rights reserved.
      </div>
    </footer>
  )
}
