import type { Metadata } from "next"
import { SiteHeader } from "@/components/site/header"
import { SiteFooter } from "@/components/site/footer"

export const metadata: Metadata = {
  title: "Terms of Service — Pollen",
  description: "The terms for joining the Pollen waitlist and using Pollen's website.",
}

// DRAFT — written for the pre-launch waitlist. Have a lawyer review before relying on it,
// and replace every [BRACKETED] placeholder.
const LAST_UPDATED = "October 12, 2026"
const COMPANY = "[COMPANY LEGAL NAME]"
const CONTACT = "contact@usepollen.ai"

const SECTIONS: { title: string; body: React.ReactNode }[] = [
  {
    title: "1. Who we are and what these terms cover",
    body: (
      <>
        <p>
          Pollen (&ldquo;Pollen,&rdquo; &ldquo;we,&rdquo; &ldquo;us&rdquo;) is operated by {COMPANY}, based in Texas,
          USA. Pollen is building a service that lets people license their videos, photos and audio to companies that use them
          to train AI models, with people getting paid for the content they contribute.
        </p>
        <p>
          Pollen hasn&apos;t launched yet. These terms cover using this website and joining the waitlist. By joining the
          waitlist or using the site, you agree to them. If you don&apos;t agree, please don&apos;t use the site.
        </p>
      </>
    ),
  },
  {
    title: "2. Who can join",
    body: (
      <>
        <p>
          Pollen is for adults. You must be at least 18 years old (or the age of majority where you live, if higher) to
          join the waitlist, and the same will apply to selling or licensing content and receiving payouts when Pollen
          launches. By joining, you confirm you meet this requirement.
        </p>
        <p>
          We don&apos;t knowingly collect information from anyone under 18. If we learn someone under 18 has joined, we
          will delete their entry. If you think that&apos;s happened, email us.
        </p>
      </>
    ),
  },
  {
    title: "3. The waitlist",
    body: (
      <ul>
        <li>Joining the waitlist is free and doesn&apos;t obligate you to anything.</li>
        <li>
          Joining doesn&apos;t guarantee you access to Pollen, a launch date, or any particular feature. We may change,
          delay, pause, or cancel the product or the waitlist at any time.
        </li>
        <li>
          Your position on the list is an estimate. It can change as people join, refer friends, or are removed, and we
          may let people in in a different order (for example, by region or by the kind of content they have).
        </li>
        <li>
          We may remove entries that look fake, duplicated, automated, or abusive, or that break these terms.
        </li>
      </ul>
    ),
  },
  {
    title: "4. Referrals",
    body: (
      <ul>
        <li>You can share your referral link to move up the list. One person, one spot.</li>
        <li>
          Don&apos;t game it: no fake or throwaway emails, bots, buying or selling signups, or spamming people who
          didn&apos;t ask to hear from you.
        </li>
        <li>
          We may adjust or void referral credit we think was earned unfairly, and we may change how referrals work at
          any time. Referral credit has no cash value and can&apos;t be transferred.
        </li>
      </ul>
    ),
  },
  {
    title: "5. No promises about earnings",
    body: (
      <p>
        Anything on this site about payouts — per-task rates, examples, or what affects earnings — is an estimate only. We
        don&apos;t promise that you&apos;ll earn any amount, or anything at all. Actual rates, eligibility, and payout
        rules will be set out in the terms you agree to when Pollen launches.
      </p>
    ),
  },
  {
    title: "6. Your content (after launch)",
    body: (
      <>
        <p>
          You don&apos;t upload any videos, photos or audio by joining the waitlist, and joining doesn&apos;t give us any rights
          to your content.
        </p>
        <p>
          When Pollen launches, content you submit will need to be real and original: photos and recordings you captured
          yourself, not generated or materially altered with AI, not copied from someone else, and not low-effort filler.
          We may review every upload and reject or remove content that doesn&apos;t meet our standards or a shot
          list&apos;s requirements, and rejected content won&apos;t be licensed or paid for.
        </p>
        <p>
          When Pollen launches, uploading and licensing content will be covered by a separate creator agreement that
          you&apos;ll need to accept. Our plan is that it will reflect the principles on this site: you choose what&apos;s
          for sale, you give clear consent for each upload, faces and voices are never licensed without your explicit
          opt-in, and you can delete your content. That agreement, not this page, will control.
        </p>
      </>
    ),
  },
  {
    title: "7. Emails from us",
    body: (
      <p>
        By joining, you agree that we can email you about your spot on the list, Pollen&apos;s launch, and updates
        about the product. Every email will include a way to unsubscribe, and unsubscribing removes you from those
        emails (you can also ask us to delete your waitlist entry — see section 13).
      </p>
    ),
  },
  {
    title: "8. Privacy",
    body: (
      <p>
        Right now we collect your email address, your referral code, who referred you (if anyone), and when you signed
        up. We use this to run the waitlist and contact you about Pollen. We don&apos;t sell your email address. Our
        Privacy Policy [link] explains this in more detail.
      </p>
    ),
  },
  {
    title: "9. Using the site",
    body: (
      <p>
        Don&apos;t misuse the site: no trying to break or overload it, scraping it, getting around security, submitting
        other people&apos;s email addresses without permission, or using it for anything illegal.
      </p>
    ),
  },
  {
    title: "10. Our stuff",
    body: (
      <p>
        The Pollen name, logo, site design, and text belong to {COMPANY}. You can link to and share the site, but
        please don&apos;t copy our branding or pass yourself off as Pollen. Photos shown on the site are examples used
        with their owners&apos; permission.
      </p>
    ),
  },
  {
    title: "11. Disclaimers and limits",
    body: (
      <>
        <p>
          The site and waitlist are provided &ldquo;as is&rdquo; and &ldquo;as available,&rdquo; without warranties of
          any kind, to the extent the law allows. We don&apos;t promise the site will always be available or
          error-free.
        </p>
        <p>
          To the extent the law allows, {COMPANY} won&apos;t be liable for indirect, incidental, or consequential
          damages arising from the site or the waitlist, and our total liability for any claim related to them is
          limited to $50. Some places don&apos;t allow these limits, so they may not apply to you.
        </p>
      </>
    ),
  },
  {
    title: "12. Changes to these terms",
    body: (
      <p>
        We&apos;ll update these terms as Pollen gets closer to launch. When we do, we&apos;ll change the date at the top
        of this page, and if the change is significant we&apos;ll email people on the waitlist. Continuing to use the
        site or stay on the waitlist after a change means you accept the updated terms.
      </p>
    ),
  },
  {
    title: "13. Leaving the waitlist",
    body: (
      <p>
        You can leave anytime. Email us at {CONTACT} from the address you signed up with and we&apos;ll delete your
        entry. We can also remove anyone from the waitlist, for any reason, including breaking these terms.
      </p>
    ),
  },
  {
    title: "14. Governing law",
    body: (
      <p>
        These terms are governed by the laws of the State of Texas, without regard to its conflict-of-law rules. Any
        dispute will be handled in the state or federal courts located in [COUNTY] County, Texas, unless the law where
        you live says otherwise.
      </p>
    ),
  },
  {
    title: "15. Contact",
    body: <p>Questions about these terms? Email {CONTACT}.</p>,
  },
]

export default function TermsPage() {
  return (
    <>
      <SiteHeader />
      <main className="px-3 py-3">
        <article className="mx-auto max-w-[860px] rounded-[36px] bg-white px-[clamp(20px,5vw,64px)] py-[clamp(36px,6vw,72px)]">
          <span className="rounded-full bg-lime px-3 py-1.5 font-mono text-xs tracking-[.08em] text-ink-2 uppercase">
            Draft · last updated {LAST_UPDATED}
          </span>
          <h1 className="wide mt-5 mb-4 font-display text-[clamp(40px,7vw,72px)] leading-[.95] font-black tracking-[-0.04em] text-ink">
            Terms of Service
          </h1>
          <p className="m-0 text-lg leading-relaxed text-moss">
            The short version: Pollen is 18+. Joining the waitlist is free, doesn&apos;t guarantee anything, and doesn&apos;t give us
            any rights to your photos or audio. Play fair with referrals. We&apos;ll only email you about Pollen, and
            you can leave anytime.
          </p>
          <div className="mt-10 flex flex-col gap-9 text-base leading-relaxed text-ink-2 [&_li]:pl-1 [&_p]:m-0 [&_p+p]:mt-3 [&_ul]:m-0 [&_ul]:flex [&_ul]:list-disc [&_ul]:flex-col [&_ul]:gap-2 [&_ul]:pl-5 [&_ul]:marker:text-leaf">
            {SECTIONS.map((s) => (
              <section key={s.title} className="flex flex-col gap-3">
                <h2 className="m-0 text-xl font-extrabold text-ink">{s.title}</h2>
                {s.body}
              </section>
            ))}
          </div>
        </article>
      </main>
      <div className="h-12" />
      <SiteFooter />
    </>
  )
}
