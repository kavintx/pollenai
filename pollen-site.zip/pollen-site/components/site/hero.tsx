import { HeroVisual } from "./hero-visual"
import { WaitlistCount, WaitlistForm } from "./waitlist"

export function Hero() {
  return (
    <section id="top" className="px-3 pt-3">
      <div className="relative">
        <div className="relative mx-auto grid max-w-[1240px] grid-cols-[repeat(auto-fit,minmax(min(500px,100%),1fr))] items-center gap-[clamp(40px,5vw,64px)] px-[clamp(16px,3vw,28px)] py-[clamp(40px,7vw,96px)]">
          <div className="flex animate-rise flex-col gap-6">
            <div className="inline-flex items-center gap-2.5 self-start rounded-full bg-white px-3.5 py-2 font-mono text-xs uppercase tracking-[.06em] text-ink-2">
              <span className="size-2 animate-pulse-dot rounded-full bg-[#3d5a0e]" />
              <WaitlistCount />
            </div>
            <h1 className="wide m-0 font-display text-[clamp(50px,8.6vw,118px)] leading-[.9] font-black tracking-[-0.045em] text-balance text-ink">
              Your camera roll is{" "}
              <span className="rounded-[.14em] bg-white px-[.12em] [box-decoration-break:clone] [-webkit-box-decoration-break:clone]">
                worth money.
              </span>
            </h1>
            <p className="m-0 max-w-[520px] text-[clamp(17px,1.6vw,20px)] leading-normal font-medium text-pretty text-[#33470f]">
              AI companies need real video, photos and sound to train their models. Pollen gives you a shot list, you
              shoot it on your phone, and you get paid for every approved task — only with your OK.
            </p>
            <div id="join" className="max-w-[560px] scroll-mt-28">
              <WaitlistForm id="hero-email" />
            </div>
          </div>

          <HeroVisual />
        </div>
      </div>
    </section>
  )
}
