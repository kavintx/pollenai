"use client"

import * as React from "react"
import dynamic from "next/dynamic"
import { AudioLines, DollarSign, ImageIcon } from "lucide-react"
import { LogoMark } from "./logo"

function StaticLogo() {
  return (
    <div className="size-full animate-float drop-shadow-[0_30px_40px_rgba(45,69,0,.22)]">
      <LogoMark className="size-full" />
    </div>
  )
}

// three.js only loads in the browser, after the page is up; the flat logo shows until then.
const Logo3D = dynamic(() => import("@/components/ui/logo-3d"), { ssr: false, loading: () => <StaticLogo /> })

/** Hero art: the 3D logo with the status cards drifting around it at different depths. */
export function HeroVisual() {
  const ref = React.useRef<HTMLDivElement>(null)
  const [webgl, setWebgl] = React.useState(true)

  // parallax for the cards: they shift with the cursor, the "closer" ones more
  React.useEffect(() => {
    const el = ref.current
    if (!el || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return
    let raf = 0
    const cur = { x: 0, y: 0 }
    const tgt = { x: 0, y: 0 }
    const tick = () => {
      cur.x += (tgt.x - cur.x) * 0.08
      cur.y += (tgt.y - cur.y) * 0.08
      el.style.setProperty("--px", cur.x.toFixed(3))
      el.style.setProperty("--py", cur.y.toFixed(3))
      raf = Math.abs(tgt.x - cur.x) + Math.abs(tgt.y - cur.y) > 0.001 ? requestAnimationFrame(tick) : 0
    }
    const onMove = (e: PointerEvent) => {
      if (e.pointerType !== "mouse") return
      const r = el.getBoundingClientRect()
      tgt.x = Math.max(-1, Math.min(1, (e.clientX - (r.left + r.width / 2)) / (r.width / 2)))
      tgt.y = Math.max(-1, Math.min(1, (e.clientY - (r.top + r.height / 2)) / (r.height / 2)))
      if (!raf) raf = requestAnimationFrame(tick)
    }
    window.addEventListener("pointermove", onMove, { passive: true })
    return () => {
      window.removeEventListener("pointermove", onMove)
      cancelAnimationFrame(raf)
    }
  }, [])

  return (
    <div ref={ref} className="relative h-[clamp(400px,42vw,560px)] animate-rise [animation-delay:.15s]">
      <div className="absolute top-1/2 left-1/2 aspect-square w-[min(440px,92%)] -translate-x-1/2 -translate-y-1/2">
        {webgl ? <Logo3D className="size-full" onUnsupported={() => setWebgl(false)} /> : <StaticLogo />}
      </div>

      <Chip depth={-18} className="top-[4%] left-0" bob="" icon={<ImageIcon className="size-5" />} title="IMG_2231.jpg" sub="Matched with a vision lab" mono />
      <Chip
        depth={26}
        className="top-[44%] right-0"
        bob="[animation-delay:.8s] [animation-duration:5s]"
        icon={<AudioLines className="size-5" />}
        iconBg="bg-[#eaf5c6]"
        title="rain_on_window.m4a"
        sub="Licensed · you said yes"
        mono
      />
      <Chip
        depth={40}
        className="bottom-[4%] left-[6%]"
        bob="[animation-delay:1.4s] [animation-duration:4s]"
        icon={<DollarSign className="size-5" />}
        title="Payout sent"
        sub="Your cut is on its way"
        dark
      />
    </div>
  )
}

function Chip({
  className,
  depth,
  bob,
  icon,
  iconBg = "bg-lime",
  title,
  sub,
  mono,
  dark,
}: {
  className: string
  depth: number
  bob: string
  icon: React.ReactNode
  iconBg?: string
  title: string
  sub: string
  mono?: boolean
  dark?: boolean
}) {
  return (
    <div
      aria-hidden
      className={`pointer-events-none absolute z-10 ${className}`}
      style={{ transform: `translate3d(calc(var(--px, 0) * ${depth}px), calc(var(--py, 0) * ${depth * 0.6}px), 0)` }}
    >
      <div
        className={`flex max-w-60 animate-bob items-center gap-3 rounded-[20px] py-2.5 pr-4 pl-2.5 shadow-[0_14px_30px_rgba(45,69,0,.16)] ${
          dark ? "bg-forest" : "bg-white"
        } ${bob}`}
      >
        <div className={`grid size-[42px] shrink-0 place-items-center rounded-[13px] text-ink-2 ${dark ? "bg-lime" : iconBg}`}>{icon}</div>
        <div className="flex min-w-0 flex-col gap-0.5">
          <span className={mono ? "font-mono text-[13px] text-ink-2" : dark ? "text-sm font-extrabold text-white" : "text-sm font-extrabold"}>
            {title}
          </span>
          <span className={dark ? "text-[13px] font-semibold text-lime" : "text-[13px] font-semibold text-moss"}>{sub}</span>
        </div>
      </div>
    </div>
  )
}
